<?php $IEM = $tpl->Get('IEM'); ?>		</div>
	</div>
	<div class="PageFooter" style="text-align: right;">
		<?php print GetLang('Copyright'); ?>
	</div>
	<div id="token" style="display:none;"><?php echo $tpl->Get('random'); ?></div>
</div>
</body>
</html>
